import UIKit
//СВОЙСТВА И МЕТОДИ

//class Animal {
//    var name: String
//    var age: Int
//    
//    init(n: String, a: Int) {
//        name = n
//        age = a
//    }
//    
//    convenience init () {
//        self.init(n: "", a: 0)
//    }
//    func eat() {
//        print("i can eat")
//    }
//}
//let pig = Animal()
//    pig.name = "Tom"
//    pig.age = 10
////    pig.eat()
//
//let cat = Animal()
//
//let arrayOfAnimals = [pig, cat]
//
//arrayOfAnimals.first?.eat()
//
//let dog = Animal(n: "kashtan", a: 8)
//
//class phone {
//    var number: Int
//    var model: String
//    var weight: Int
//    init (n: Int, m: String, w: Int){
//        number = n
//        model = m
//        weight = w
//    }
//    func recieveCall(name :String, number: Int) {
//        print("Вам звонит \(name),\(number)")
//    }
//    func getNumber(number:Int) -> Int{
//        print(number)
//        return number
//    }
//}
//func sendMessage(_ number1: Int, _ number2: Int, _ number3: Int) {
//    print(number1, number2, number3)
//    return
//}
//let iphone1 = phone(n: 14, m:"Pro", w: 300)
//let iphone2 = phone(n: 13, m: "Pro Max", w: 320)
//
//let myPhones = [iphone1, iphone2]
////for i in myPhones {
////    i.recieveCall(name: "Sasa")
////    i.getNumber(number: 48545544)
////}
//myPhones[1].recieveCall(name: "neizvestno", number: 77776666)
//sendMessage(3445, 35667, 444677)
//
//
//class Animal {
//    var name: String
//    var age: Int
//    init() {
//        print ("Animal - init")
//    }
//    func move() {
//        print("I can move")
//    }
//    deinit {
//        print("Animal - deinit")
//    }
//}
//
////НАСЛІДУВАННЯ
//
//class fish: Animal {
//    override func move(){
//        super.move()
//        print("I can swim")
//    }
//}
//
//class Bird: Animal {
//    override func move() {
////        super.move()
//        print("I can fly")
//    }
//}
//
//let fish1 = fish()
//fish1.move()
//
//let bird1 = Bird()
//fish1.move()
//
//struct house {
//    var numberOfRooms: Int
//    var height: Int
//}
//
//let house1 = house(numberOfRooms: 3, height: 100)

//class Calculator {
//    func sum(a: Int, b: Int) -> Int {
//        let result =  a + b
//        return result
//    }
//    func minus(a: Int, b: Int) -> Int {
//        let result = a - b
//        return result
//    }
//    func mult(a: Int, b: Int) -> Int {
//        let result = a * b
//        return result
//    }
//    func div(a: Int, b: Int) -> Int {
//        let result = a / b
//        return result
//    }
//    func rem(a: Int, b: Int) -> Int {
//        let result = a % b
//        return result
//    }
//}
//
//let myFirstCalculator = Calculator()
//
//class SuperCalculator : Calculator {
//    func percent(a: Int, b: Int) -> Int {
//        var result = (a / 100) * b
//        return result
//    }
//    
//
//    
//    
//    
//    func pow (a: Int, b: Int) -> Int {
//        if b == 0 {
//            return 1
//        }
//        if b == 1 {
//            return a
//        }
//        else {
//            var positiveNumber = b
//            var result: Int = 1
//            for i in 1...positiveNumber {
//                result = result * a
//            }
//            return result
//        }
//    }
//    
//}
//let mySecondCalculator = SuperCalculator()
//
//mySecondCalculator.percent(a: 500, b: 2)
//
//print(mySecondCalculator.mult(a: 4, b: 10))

//class Car {
//    var name: String
//    
//    init(name: String) {
//        self.name = name
//    }
//}
//func drive () {
//    print("Car drives good")
//    
//}
//class Truck: Car {
//    var model: String
//    init(name: String, model: String) {
//        self.model = model
//        super.init(name: name)
//    }
//    override func drive() {
//        print("\name is truck")
//    }
//}
//
//let firstCar = Car(name:"Q1")
//firstCar.drive
//

// ОПЦІОНАЛИ
//force unwrap
//var test: String? = "nill"
//test = "some value"

//safe unwrap

//let new = test ?? ""
//print(new)
//if let test = test {
//    print(test)
//}
//
//@MainActor func unwrapIt() {
//    guard let test = test else {
//        return
//    }
//    print(test)
//}
//unwrapIt()
//
//var someOpt: Int? = nil
//let tester = someOpt ?? 4
//print(tester)
//
//if let tester = someOpt {
//    print("good mate")
//}
//

//var name: String? = "oleg"
//
//
//if name != nil {
//    print("Ім'я: \(name!)") // Використовується "примусовий розпак" (!)
//}
//
//if let unwrappedName = name {
//    print("imia \(unwrappedName)")
//}
//    else {
//        print("no name")
//    }
//
//
//let userName = name ?? "gost"
//print(userName)
//
//var optionalString: String? = "Привіт, Swift!"
//var optionalInt: Int? = 42
//var optionalFloat: Float? = 3.14
//var optionalBool: Bool? = true

//if optionalString != nil {
//    print("Примусове розгортання: \(optionalString!)")
//}
//
//if optionalString == "Привіт, Swift!" {
//    print("its unwrappd")
//}
//if let unwrappedString = optionalInt {
//    print("this os also OK")
//}
//
//let defoultFloat = optionalFloat ?? 0.0
//print(defoultFloat)
//
//func unwrapping() {
//    guard let unwrapfunc = optionalBool else {
//        print("its nill")
//        return
//    }
//    print("its wrapped")
//}
//
//Створіть масив з десятьма випадковими числами, з яких п'ять менше за нуль і п'ять більше за нуль. Виконайте наступні дії:
//1. Замініть усі негативні числа на 0 і виведіть масив у консоль.
//Як вирішити дану задачу не використовуючи два наступні способи

//var randomArray = [-7, -4, -14, -20, -40, 2, 4, 6, 7 ,8]
//
//for (index, element) in randomArray.enumerated() {
//    if element < 0 {
//        randomArray[index] = 0
//    }
//}
//print(randomArray)
//
//let modifiedArray = randomArray.map { $0 < 0 ? 0 : $0 }
//print(modifiedArray)
//

//class Car {
//    var name: String
//    
//    init(name: String) {
//        self.name = name
//    }
//
//    func drive () {
//        print("Car drives good")
//    }
//    
//}
//class Truck: Car {
//    var model: String
//    init(name: String, model: String) {
//        self.model = model
//        super.init(name: name)
//    }
//    override func drive() {
//        print("\(model) is truck")
//    }
//  
//}
//
//var firstTruck = Truck(name:"Q1", model: "sedan")
//firstTruck.drive()
//
//
//

//protocol Flyable {
//    func fly()
//    }
//
//class Eagle: Flyable {
//    func fly() {
//        print("Eagle is flying") }
//    }
//    
//struct Airplane: Flyable {
//    func fly() {
//        print("Airplane is flying") }
//        }


//protocol Unit {
//    func attack()
//}
//
//class Attackers: Unit {
//    func attack() {
//        print("Fight!!!")
//    }
//}
//
//var soldier, ship, tank: Attackers
//let newArray = [Attackers()]
//for i in newArray {
//    i.attack()
//}
//
//extension Double {
//    var km: Double { return self * 1000 }
//    var m: Double { return self }
//    var cm: Double { return self / 100 }
//}
//let distance = 5.km + 354.m + 45.cm
//print(distance)
//
//protocol Flyable {
//    func fly()
//}
//extension Flyable {
//    func fly() {print("FLY")}
//}
//struct Bird: Flyable {
//    }
//
//let myBird = Bird()
//myBird.fly()
//
//
//struct Airplane {
////    func
////    func
////    func
////    func
////    func
//}
//
//extension Airplane: Flyable {
//    func fly() { }
//}
//
//
//protocol Runnable {
//    func run()
//}
//extension Runnable {
//    func run() {
//        print("Run")
//    }
//}
//protocol Flyable {
//    func fly()
//}
//
//extension Flyable {
//    func fly() {
//        print("Fly")
//    }
//}
//
//protocol Alive {
//    func breathe()
//    func eat()
//    func grow()
//}
//
//extension Alive {
//    func breathe () {
//        print("breathe")
//    }
//    func eat() {
//        print("eat")
//    }
//}
//
//struct Bird: Flyable {
//var name = "1"
//    func fly() {}
//}
//
//struct Wolf: Runnable {
//    func run() {}
//}
//
//struct Human: Alive {
//    func breathe() {}
//    func eat() {}
//    func grow() {}
//}
//
//
//
//var person1: Bird
//var person2: Bird
//var person3: Wolf
//var person4: Wolf
//var person5: Human
//var person6: Human

//
//func wrap<T, D>(key: T, val: D) -> [T:D] {
//    [key: val]
//}
//
//func isEqual<T: Comparable & Flyable>(val1: T, val2: T) -> Bool {
//    val1 == val2
//}
//
//protocol Flyable {
//    func fly()
//}
//
//
//let strings = ["strOne", "strTwo"]
//let integers = [1, 2, 3]
//let doubles = [2.4, 3.7, 1.2]
//
//func showAsText<T>(value: T) -> String {
//    "\(value)"
//}
//showAsText(value: 5)
//showAsText(value: true)
//showAsText(value: 3.5)
//showAsText(value: "good")
//
//struct Collection<Element> {
//    var elements : [Element] = []
//    
//    func printCollection() {
//        for i in elements {
//            print(i)
//        }
//    }
//}
//
//var collectionOne = Collection<Int>(elements: [1, 4, 5, 8])
//
//
//var collectionTwo = Collection<String>(elements: ["3434", "345", "frfff"])
//
//func swap<T>(a: T, b: T) -> (T, T) {
//    var temp = a
//    var temp1 = b
//     return (temp1, temp)
//}
//
//
//func swap1(a: Int, b: Int) -> (Int, Int) {
//   var temp = a
//   var temp1 = b
//    return (temp1, temp)
//}
//
//swap1(a: 3, b: 7)
//print(swap1(a: 30, b: 2))
//
//print(swap(a: "dsds", b: "344343"))
//
//
//func tuplee<T>(a: T, b: T) -> (T, T) {
//    (a, b)
//}
//
//
//
//enum Degree {
//    case bachelors
//    case masters
//}
//
//struct Person {
//    var name: String
//    var degree: Degree
//}
//
//var alice = Person(name: "Alice", degree: .bachelors)
//alice.degree = .masters
//
//switch alice.degree {
//case .bachelors:
//    print("cool")
//case .masters:
//    print("even better")
//}
//
//enum Day: CaseIterable {
//    
//    case Monday
//    case Tuesday
//    case Wednesday
//    case Thursday
//    case Friday
//    case Saturday
//    case Sunday
//    
//    func dayType() -> String {
//        switch self {
//        case.Monday, .Tuesday, .Wednesday, .Thursday, .Friday:
//            return "week day"
//        case.Saturday, .Sunday:
//            return "weekend"
//        }
//    }
//}
//
//let dayofWeek = Day.Sunday
//let arrayOfValues = [Day.allCases]
//
//let dayType = dayofWeek.dayType()
//
//enum SizeOfPizza: Int {
//    case small = 12
//    case medium = 18
//    case large = 25
//    case extraLarge = 50
//}
//
//let size = SizeOfPizza.small
//
//
//let newSize = SizeOfPizza(rawValue: 50)
//
//enum Distance {
//    case km(Int)
//    case mi(Float)
//}
//let distanceToMyScool = Distance.mi(12)
//
//func getMessage(distance: Distance) -> String {
//    switch distance {
//    case .km(let distanceKM):
//        return "distance in km is \(distanceKM)"
//    case .mi(let distanceMi):
//        return "distance in mi is \(distanceMi)"
//    
//    }
//}
//
//enum carModel: String  {
//    case BMW = "ffff"
//    case Audi = "fdfdf"
//    case WW = "ppppp"
//    case Volvo = "hh"
//}
//
//enum footballClub {
//    case Arsenal
//    case Liverpool
//    case Real
//    case Barca
//    
//    func pointsInTable() -> Int {
//        switch self {
//        case .Arsenal:
//            return 90
//        case .Liverpool:
//            return 89
//        case .Real:
//            return  89
//        case .Barca:
//            return  70
//        }
//    }
//}
//
//let currentClub = footballClub.Arsenal
//currentClub.pointsInTable()

//class BirdClass {
//    var name: String = ""
//    var canFly: Bool = true
//    var flySpeed: Double = 0
//    func distance(second: Float) -> Float { return 0 }
//}
//
//class SwanWhiteClass: BirdClass {
//    
//}
//
//class SwanblackClass: BirdClass {
//    
//}
//
//class PenguinClass: BirdClass {
//    
//    
//}
//protocol Bird {
//    var name: String { get }
//    var canFly: Bool { get }
//}
//
//protocol FlyingBird {
//    var flySpeed: Float { get }
//}
//
//extension Bird {
//    var canFly: Bool {
//        return false
//    }
//}
//extension Bird where Self: FlyingBird {
//    var canFly: Bool {
//        return true
//    }
//}
//
//extension FlyingBird {
//    func distance(seconds: Float) -> Float {
//        seconds * flySpeed
//    }
//}
//
//struct Penguin: Bird {
//    var name: String
//}
//
//let myPenguin = Penguin(name: "Bob")
//myPenguin.canFly
//
//enum Swan: String, Bird, FlyingBird {
//    case white
//    case black
//    var flySpeed: Float {
//        switch self {
//        case.white: return 100
//        case.black: return 150
//        }
//    }
//    var name: String {
//        return self.rawValue
//    }
//}
//
//var myFirstSwan = Swan.black
//myFirstSwan.canFly
//myFirstSwan.flySpeed
//myFirstSwan.distance(seconds: 120)
//
//enum VehicleType: String {
//    case electric
//    case nonElectric
//}
//
//protocol Vehicle {
//    var weight: Float { get }
//    var speed: Float { get }
//    var type: VehicleType { get }
//    var canFly: Bool { get }
//    func prepare()
//}
//
//extension Vehicle {
//    var canFly: Bool {
//        return false
//        func prepare() {
//            switch type {
//            case.electric: return print("Charge")
//            case.nonElectric: return print("Refuel")
//            }
//        }
//    }
//}
//
//protocol FlyableVehince {
//    func getMaxHight() ->  Float
//}
//
//extension Vehicle where Self: FlyableVehince {
//    var canFLy: Bool {
//        return true
//    }
//    var type: VehicleType {
//        return .nonElectric
//    }
//    func getMaxHight() -> Float {
//        switch type {
//        case.electric: return weight + speed
//        case.nonElectric: return weight * speed
//        }
//    }
//}
//
//struct Car: Vehicle {
//    var weight: Float
//    var speed: Float
//    var type: VehicleType
//    var canFly: Bool
//    func prepare() {
//        switch type {
//        case.electric: return print("Charge")
//        case.nonElectric: return print("Refuel")
//        }
//    }
//    
//    struct ElectricCar: Vehicle {
//        var weight: Float
//        var speed: Float
//        var type: VehicleType
//        var canFly: Bool
//        func prepare() {
//            switch type {
//            case.electric: return print("Charge")
//            case.nonElectric: return print("Refuel")
//            }
//        }
//    }
//    
//    struct AirPlane: Vehicle, FlyableVehince {
//        var weight: Float
//        var speed: Float
//        var type: VehicleType
//        var canFly: Bool
//        func prepare()  {
//            switch type {
//            case.electric: return print("Charge")
//            case.nonElectric: return print("Refuel")
//            }
//        }
//        }
//        func getMaxHight() -> Float {
//            switch type {
//            case.electric: return weight + speed
//            case.nonElectric: return weight * speed
//            }
//        }
//    }
//
//
//var myVolvo = Car(weight: 900, speed: 120, type: .nonElectric, canFly: false)
//
//var myTesla = Car(weight: 700, speed: 100, type: .electric, canFly: false)
//
//var myBoing = Car(weight: 5000, speed: 3000, type: .nonElectric, canFly: true)



//protocol Animal {
//    func makeSound()
//}
//
//class Dog: Animal {
//    func makeSound() {
//        print("Гав-гав")
//    }
//}
//
//class Cat: Animal {
//    func makeSound() {
//        print("Мяу")
//    }
//}
//
//func voice(animal: Animal) {
//    animal.makeSound()
//}

//protocol Flyable {
//    func fly()
//}
//
//extension Flyable {
//    func fly() {
//        print("Im flying")
//    }
//}
//
//class Bird: Flyable {
//}
//
//class Superman: Flyable {
//     func fly() {
//        print("Im flying as superman")
//    }
//}
//
//let bird = Bird()
//bird.fly()
//
//let superman = Superman()
//superman.fly()

//protocol Readable {
//    func read()
//}
//
//protocol Writeable {
//    func write()
//}
//
//class Student: Readable, Writeable {
//    func read() {
//        print("I can read")
//    }
//    func write() {
//        print("I can write")
//    }
//}
//
//func someFunc(someValue: Readable & Writeable ) {
//    someValue.read()
//    someValue.write()
//}


